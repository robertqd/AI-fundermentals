# NVIDIA NVDEC 解码文档离线包

本压缩包包含两类材料，方便离线阅读：

1. **本仓库整理的中文指南**（原创学习笔记）
2. **NVIDIA Video Codec SDK 13.1 官方公开文档的离线副本**（版权归 NVIDIA）

## 中文指南（建议先读）

| 文件 | 说明 |
| :--- | :--- |
| `01_nvidia_decode_pipeline.html` | 浏览器直接打开 |
| `01_nvidia_decode_pipeline.md` | Markdown 源文件 |
| `assets/nvidia_decode_pipeline.svg` | 解码流水线全景图 |

## 官方文档离线副本（SDK 13.1，抓取于 2026-08-20）

| 文档 | Markdown | HTML | 原文 |
| :--- | :--- | :--- | :--- |
| NVDEC Video Decoder API Programming Guide (SDK 13.1) | [official/NVDEC_Video_Decoder_API_Programming_Guide.md](official/NVDEC_Video_Decoder_API_Programming_Guide.md) | [official/NVDEC_Video_Decoder_API_Programming_Guide.html](official/NVDEC_Video_Decoder_API_Programming_Guide.html) | <https://docs.nvidia.com/video-technologies/video-codec-sdk/13.1/nvdec-video-decoder-api-prog-guide/> |
| NVDEC Application Note (SDK 13.1) | [official/NVDEC_Application_Note.md](official/NVDEC_Application_Note.md) | [official/NVDEC_Application_Note.html](official/NVDEC_Application_Note.html) | <https://docs.nvidia.com/video-technologies/video-codec-sdk/13.1/nvdec-application-note/> |
| Using FFmpeg with NVIDIA GPU Hardware Acceleration (SDK 13.1) | [official/Using_FFmpeg_with_NVIDIA_GPU_Hardware_Acceleration.md](official/Using_FFmpeg_with_NVIDIA_GPU_Hardware_Acceleration.md) | [official/Using_FFmpeg_with_NVIDIA_GPU_Hardware_Acceleration.html](official/Using_FFmpeg_with_NVIDIA_GPU_Hardware_Acceleration.html) | <https://docs.nvidia.com/video-technologies/video-codec-sdk/13.1/ffmpeg-with-nvidia-gpu/> |
| NVIDIA Video Codec SDK 13.1 Read Me | [official/Video_Codec_SDK_13.1_ReadMe.md](official/Video_Codec_SDK_13.1_ReadMe.md) | [official/Video_Codec_SDK_13.1_ReadMe.html](official/Video_Codec_SDK_13.1_ReadMe.html) | <https://docs.nvidia.com/video-technologies/video-codec-sdk/13.1/read-me/> |
| NVIDIA Video Codec SDK 13.1 Documentation Index | [official/Video_Codec_SDK_13.1_Index.md](official/Video_Codec_SDK_13.1_Index.md) | [official/Video_Codec_SDK_13.1_Index.html](official/Video_Codec_SDK_13.1_Index.html) | <https://docs.nvidia.com/video-technologies/video-codec-sdk/13.1/> |

## 版权与使用

- 中文指南为仓库学习笔记，用于 AI 基础设施教学。
- `official/` 目录中的文件来自 [NVIDIA Video Codec SDK Documentation](https://docs.nvidia.com/video-technologies/video-codec-sdk/13.1/)，版权归 NVIDIA Corporation 所有。
- 官方 SDK 安装包需要登录 [NVIDIA Developer](https://developer.nvidia.com/video-codec-sdk) 下载，本包**不包含** SDK 二进制或样例代码。
- 请以官网最新版本为准；能力矩阵和驱动要求会随代际更新。
